----- Machine Learning Project 1 -----

Name
----
Ravi Rajpurohit

UTA ID
------
1002079916

Files description
-----------------

train.txt - train data used for question 1 and 2 Linear Regression
test.txt - test data used for question 1 and 2 Linear Regression
train_softmax - train data used for question 3 Softmax Regression
test_softmax - test data used for question 3 Softmanx Regression
project1.py - contains the python code for executing the project code
project1.ipynb - Interactive python notebook with outputs and markdowns

Run the program by
------------------
1. Make sure python is installed (version 3.9.12 used while development)
2. Open terminal and run by "python project1.py"
3. Or run in an IDE